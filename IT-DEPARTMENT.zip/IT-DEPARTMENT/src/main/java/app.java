public class app {
    
    public static void main(String[] args) {
        System.out.println("Hello CI/CD World!");
        System.out.println("Ci moven built successfully");
    }


}
